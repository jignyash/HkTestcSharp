﻿namespace HIKSDKTest
{
    partial class HIKSDKTestForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.picVideoPanel = new System.Windows.Forms.PictureBox();
            this.btnStart = new System.Windows.Forms.Button();
            this.lblNotification = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picVideoPanel)).BeginInit();
            this.SuspendLayout();
            // 
            // picVideoPanel
            // 
            this.picVideoPanel.Location = new System.Drawing.Point(53, 64);
            this.picVideoPanel.Name = "picVideoPanel";
            this.picVideoPanel.Size = new System.Drawing.Size(677, 301);
            this.picVideoPanel.TabIndex = 0;
            this.picVideoPanel.TabStop = false;
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(778, 64);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 1;
            this.btnStart.Text = "START";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // lblNotification
            // 
            this.lblNotification.ForeColor = System.Drawing.Color.Red;
            this.lblNotification.Location = new System.Drawing.Point(53, 9);
            this.lblNotification.Name = "lblNotification";
            this.lblNotification.Size = new System.Drawing.Size(677, 41);
            this.lblNotification.TabIndex = 2;
            this.lblNotification.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // HIKSDKTestForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(910, 422);
            this.Controls.Add(this.lblNotification);
            this.Controls.Add(this.btnStart);
            this.Controls.Add(this.picVideoPanel);
            this.Name = "HIKSDKTestForm";
            this.Text = "HIKTest";
            ((System.ComponentModel.ISupportInitialize)(this.picVideoPanel)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox picVideoPanel;
        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Label lblNotification;
    }
}

