﻿using HIKSDKTest.Hikvision.Base;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HIKSDKTest
{
    public partial class HIKSDKTestForm : Form
    {
        public HIKSDKTestForm()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            lblNotification.Text = string.Empty;
            btnStart.Enabled = false;
            RealPlay_Hikvision();
            btnStart.Enabled = true;
        }
        
        private IntPtr real_play;
        private bool play_video = false;
        private int realPlayId;
        private int Hik_LoginID;

        private string camera_name = "test123";
        private string camera_ip = "127.0.0.1";
        private int camera_port = 8000;

        private void RealPlay_Hikvision(int channel = 1)
        {
            if (play_video)
            {
                SDKMethods.NET_DVR_StopRealPlay(realPlayId);

                picVideoPanel.Refresh();
                play_video = false;
                SDKMethods.NET_DVR_StopRealPlay(realPlayId);
                SDKMethods.NET_DVR_Logout(Hik_LoginID);
                SDKMethods.NET_DVR_Cleanup();
                btnStart.Text = "START";
                return;
            }
            SDKMethods.NET_DVR_Init();
            SDKMethods.NET_DVR_SetConnectTime(2000, 1);
            SDKMethods.NET_DVR_SetReconnect(10000, true);
            
            NET_DVR_DEVICEINFO_V30 struDeviceInfo = new NET_DVR_DEVICEINFO_V30();
            string ip = "10.19.8.181";
            ushort port = (ushort)camera_port;
            string user = "admin";
            string password = "Tee5ithi";
            Hik_LoginID = SDKMethods.NET_DVR_Login_V30(ip, port, user, password, ref struDeviceInfo);
            if (Hik_LoginID < 0)
            {
                //result.AddError(string.Format("Login failed, error code: {0}\n", SDKMethods.NET_DVR_GetLastError()));
                //result.IsSuccessful = false;
                
                SDKMethods.NET_DVR_Cleanup();
                return;
            }


          

            NET_DVR_FIND_PICTURE_PARAM picparamtest = new NET_DVR_FIND_PICTURE_PARAM();

            NET_DVR_TIME startTime = new NET_DVR_TIME();

            startTime.dwDay = 12;
            startTime.dwHour = 12;
            startTime.dwMinute = 0;
            startTime.dwMonth = 9;
            startTime.dwSecond = 0;
            startTime.dwYear = 2018;



            NET_DVR_TIME endTime = new NET_DVR_TIME();
            endTime.dwDay = 11;
            endTime.dwHour = 10;
            endTime.dwMinute = 29;
            endTime.dwMonth = 10;
            endTime.dwSecond = 1;
            endTime.dwYear = 2018;

            picparamtest.struStartTime = startTime;
            picparamtest.struStopTime = endTime;
            picparamtest.lChannel = channel;

            var retu = SDKMethods.NET_DVR_FindPicture(Hik_LoginID, ref picparamtest);

            var eror = SDKMethods.NET_DVR_GetLastError();

            real_play = picVideoPanel.Handle;
            SDKMethods.fRealDataCallBack_V30 callback = new SDKMethods.fRealDataCallBack_V30(g_RealDataCallBack_V30);
            NET_DVR_PREVIEWINFO Hik_PrevInfo = new NET_DVR_PREVIEWINFO();
            
            try
            {
                Hik_PrevInfo.hPlayWnd = real_play;
                Hik_PrevInfo.lChannel = channel; //Preview channel NO.
                Hik_PrevInfo.dwStreamType = 0; //0-main stream, 1-sub stream, 2-stream3, 3-stream4.
                Hik_PrevInfo.dwLinkMode = 0; //0-TCP mode, 1-UDP mode, 2-Multi-play mode, 3-RTP mode, 4-RTP/RTSP, 5-RTSP over HTTP
                Hik_PrevInfo.bBlocked = 0;
                
                IntPtr pUser = IntPtr.Zero;


             

             

               

                realPlayId = SDKMethods.NET_DVR_RealPlay_V40(Hik_LoginID, ref Hik_PrevInfo, null, pUser);

                if (realPlayId < 0)
                {
                    string message = string.Format("RealPlay_v40 failed, error code: {0}", SDKMethods.NET_DVR_GetLastError());
                    Console.WriteLine(message);

                    var bmp = new Bitmap(picVideoPanel.ClientSize.Width, picVideoPanel.ClientSize.Height);
                    using (Graphics g = Graphics.FromImage(bmp))
                    {
                        g.DrawString(message, new Font("Verdana", (float)12, FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Red), (float)20, (float)20);
                        g.Dispose();
                    }
                    picVideoPanel.Image = bmp;

                    SDKMethods.NET_DVR_StopRealPlay(realPlayId);

                    play_video = false;
                }
                else
                {
                    play_video = true;
                    btnStart.Text = "STOP";
                }
            }
            catch (Exception ex)
            {
                play_video = false;
                
                string message = string.Format("Video player, Hikvision connect: {0} - {1}:{2} - {3}", camera_name, camera_ip, camera_port, ex.Message);
                Console.WriteLine(message);

                var bmp = new Bitmap(picVideoPanel.ClientSize.Width, picVideoPanel.ClientSize.Height);
                using (Graphics g = Graphics.FromImage(bmp))
                {
                    g.DrawString(message, new Font("Verdana", (float)12, FontStyle.Bold, GraphicsUnit.Pixel), new SolidBrush(Color.Red), (float)20, (float)20);
                    g.Dispose();
                }
                picVideoPanel.Image = bmp;
                
                SDKMethods.NET_DVR_StopRealPlay(realPlayId);
                SDKMethods.NET_DVR_Logout(Hik_LoginID);
                SDKMethods.NET_DVR_Cleanup();
            }
        }
        
        public void g_RealDataCallBack_V30(int lRealHandle, uint dwDataType, byte[] pBuffer, uint dwBufSize, IntPtr pUser)
        {
            //Console.WriteLine("Hello from g_RealDataCallBack_V30");
            //MessageBox.Show("Test");
        }

    }
}
