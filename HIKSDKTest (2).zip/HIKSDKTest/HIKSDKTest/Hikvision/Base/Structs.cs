﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using static HIKSDKTest.Hikvision.Base.SDKMethods;

namespace HIKSDKTest.Hikvision.Base
{
    #region RealPlay_V40

    public static class SDKConst
    {
        public const int STREAM_ID_LEN = 32;
        public const int RES_LEN = 30;
        public const int NET_DVR_PLAYSTART = 1;
        public const int NET_DVR_SET_TRANS_TYPE = 32;
        public const int SERIALNO_LEN = 48;

        public const int NET_DVR_DEV_ADDRESS_MAX_LEN = 129;
        public const int NET_DVR_LOGIN_USERNAME_MAX_LEN = 64;
        public const int NET_DVR_LOGIN_PASSWD_MAX_LEN = 64;

        public const int DESC_LEN_32 = 32;
        public const int MAX_NODE_NUM = 256;
        public const int MAX_ABILITYTYPE_NUM = 12;
    }

    public struct NET_DVR_TIME
    {
        public int dwYear;
        public int dwMonth;
        public int dwDay;
        public int dwHour;
        public int dwMinute;
        public int dwSecond;
    }

    public struct NET_DVR_PLAYCOND
    {
        public uint dwChannel;
        public NET_DVR_TIME struStartTime;
        public NET_DVR_TIME struStopTime;
        public byte byDrawFrame;
        public byte[] byRes;

    }

    public struct NET_DVR_PREVIEWINFO
    {
        public int lChannel; // Channel no.
        public uint dwStreamType; // Stream type 0-main stream,1-sub stream,2-third stream,3-forth stream,4-fifth stream,5-sixth stream,7-seventh stream,8-eighth stream,9-ninth stream,10-tenth stream
        public uint dwLinkMode; // Protocol type: 0-TCP, 1-UDP, 2-Muticast, 3-RTP,4-RTP/RTSP, 5-RSTP/HTTP
        public IntPtr hPlayWnd; // Play window's handle; set NULL to disable preview
        public uint bBlocked; //If data stream requesting process is blocked or not: 0-no, 1-yes 
                              //if true, the SDK Connect failure return until 5s timeout , not suitable for polling to preview.
        public uint bPassbackRecord; //0- not enable ,1 enable
        public byte byPreviewMode; // Preview mode 0-normal preview,2-delay preview
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = SDKConst.STREAM_ID_LEN, ArraySubType = UnmanagedType.I1)]
        public byte[] byStreamID;//Stream ID
        public byte byProtoType; //0-private,1-RTSP
        public byte byRes1;
        public byte byVideoCodingType;
        public uint dwDisplayBufNum; //soft player display buffer size(number of frames), range:1-50, default:1
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 216, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes;
    }
    #endregion RealPlay_V40

    public struct NET_DVR_DEVICEINFO_V40
    {
        public NET_DVR_DEVICEINFO_V30 struDeviceV30;
        public byte bySupportLock;
        public byte byRetryLoginTime;
        public byte byPasswordLevel;

        public byte byProxyType;  //Proxy Type,0-not use proxy, 1-use socks5 proxy, 2-use EHome proxy
        public uint dwSurplusLockTime;    //surplus locked time
        public byte byCharEncodeType;     //character encode type
        public byte bySupportDev5;//Support v50 version of the device parameters, device name and device type name length is extended to 64 bytes 
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 254, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes2;
    }

    public struct NET_DVR_DEVICEINFO_V30
    {
        [MarshalAs(UnmanagedType.ByValTStr, SizeConst = SDKConst.SERIALNO_LEN)]
        public string sSerialNumber;    //SN
        public byte byAlarmInPortNum;                 //Number of Alarm input
        public byte byAlarmOutPortNum;                 //Number of Alarm Output
        public byte byDiskNum;                         //Number of Hard Disk
        public byte byDVRType;                         //DVR Type,  1: DVR 2: ATM DVR 3: DVS ......
        public byte byChanNum;                         //Number of Analog Channel
        public byte byStartChan;                     //The first Channel No. E.g. DVS- 1, DVR- 1
        public byte byAudioChanNum;                 //Number of Audio Channel
        public byte byIPChanNum;                     //Maximum number of IP Channel  low
        public byte byZeroChanNum;             //Zero channel encoding number//2010- 01- 16
        public byte byMainProto;             //Main stream transmission protocol 0- private,  1- rtsp,2-both private and rtsp
        public byte bySubProto;                 //Sub stream transmission protocol 0- private,  1- rtsp,2-both private and rtsp
        public byte bySupport;         //Ability, the 'AND' result by bit: 0- not support;  1- support
                                       //bySupport & 0x1,  smart search
                                       //bySupport & 0x2,  backup
                                       //bySupport & 0x4,  get compression configuration ability
                                       //bySupport & 0x8,  multi network adapter
                                       //bySupport & 0x10, support remote SADP
                                       //bySupport & 0x20  support Raid card
                                       // bySupport & 0x40 support IPSAN directory search
        public byte bySupport1;        // Ability expand, the 'AND' result by bit: 0- not support;  1- support
                                       // bySupport1 & 0x1, support snmp v30
                                       // bySupport1& 0x2,support distinguish download and playback
                                       //bySupport1 & 0x4, support deployment level
                                       //bySupport1 & 0x8, support vca alarm time extension 
                                       //bySupport1 & 0x10, support muti disks(more than 33)
                                       //bySupport1 & 0x20, support rtsp over http
                                       //bySupport1 & 0x40, support delay preview
                                       //bySuppory1 & 0x80 support NET_DVR_IPPARACFG_V40, in addition  support  License plate of the new alarm information
        public byte bySupport2;        // Ability expand, the 'AND' result by bit: 0- not support;  1- support
                                       //bySupport & 0x1, decoder support get stream by URL
                                       //bySupport2 & 0x2,  support FTPV40
                                       //bySupport2 & 0x4,  support ANR
                                       //bySupport2 & 0x20, support get single item of device status
                                       //bySupport2 & 0x40,  support stream encryt
        public ushort wDevType;              //device type
        public byte bySupport3;        //Support  epresent by bit, 0 - not support 1 - support 
                                       //bySupport3 & 0x1-muti stream support 
                                       //bySupport3 & 0x8  support use delay preview parameter when delay preview
                                       //bySupport3 & 0x10 support the interface of getting alarmhost main status V40
        public byte byMultiStreamProto;//support multi stream, represent by bit, 0-not support ;1- support; bit1-stream 3 ;bit2-stream 4, bit7-main stream, bit8-sub stream
        public byte byStartDChan;        //Start digital channel
        public byte byStartDTalkChan;    //Start digital talk channel
        public byte byHighDChanNum;        //Digital channel number high
        public byte bySupport4;        //Support  epresent by bit, 0 - not support 1 - support
                                       //bySupport4 & 0x4 whether support video wall unified interface
                                       // bySupport4 & 0x80 Support device upload center alarm enable
        public byte byLanguageType;    // support language type by bit,0-support,1-not support  
                                       //  byLanguageType 0 -old device
                                       //  byLanguageType & 0x1 support chinese
                                       //  byLanguageType & 0x2 support english
        public byte byVoiceInChanNum;   //voice in chan num 
        public byte byStartVoiceInChanNo; //start voice in chan num
        public byte bySupport5;  //0-no support,1-support,bit0-muti stream
                                 //bySupport5 &0x01support wEventTypeEx 
                                 //bySupport5 &0x04support sence expend
        public byte bySupport6;
        public byte byMirrorChanNum;    //mirror channel num,<it represents direct channel in the recording host>
        public ushort wStartMirrorChanNo;  //start mirror chan
        public byte bySupport7;        //Support  epresent by bit, 0 - not support 1 - support 
                                       //bySupport7 & 0x1- supports INTER_VCA_RULECFG_V42 extension    
                                       // bySupport7 & 0x2  Supports HVT IPC mode expansion
                                       // bySupport7 & 0x04  Back lock time
                                       // bySupport7 & 0x08  Set the pan PTZ position, whether to support the band channel
                                       // bySupport7 & 0x10  Support for dual system upgrade backup
                                       // bySupport7 & 0x20  Support OSD character overlay V50
                                       // bySupport7 & 0x40  Support master slave tracking (slave camera)
                                       // bySupport7 & 0x80  Support message encryption 
        public byte byRes2;
    }


    //typedef struct tagNET_DVR_FIND_PICTURE_PARAM
    //{
    //    DWORD dwSize;         //Structure size
    //    LONG lChannel;       //Channel number
    //    BYTE byFileType;     //Image type to search: 0- scheduled capture, 1- motion detection capture, 2- alarm capture, 3- motion detection or alarm capture, 3-motion detection and alarm capture, 6- manual capture, 9-VCA, 0x0d facedetect,0xe NULL,Oxf field detection,0x25-face snap,0x26-Offline temperature alarm,0x2a-getup,0x2b-advreschheight,0x2c-toilettarry,0xff,0xff- all types
    //    BYTE byNeedCard;     //Whether need card number
    //    BYTE byProvince;     //Province
    //    BYTE byRes;
    //    BYTE sCardNum[CARDNUM_LEN_V30];     //Card number
    //    NET_DVR_TIME struStartTime;//Start time of image search
    //    NET_DVR_TIME struStopTime;//End time of image search
    //                              //ITC3.7 Newly added
    //    DWORD dwTrafficType; //Image retrieval; Reference  VCA_OPERATE _TYPE 
    //    DWORD dwVehicleType; //Vehicle Type; Reference VCA_VEHICLE_TYPE
    //                         //Illegal Type; Reference VCA_ILLEGAL_TYPE ;Not support check
    //    DWORD dwIllegalType;
    //    BYTE byLaneNo;  //Lane No. (1~99)
    //    BYTE bySubHvtType;//0- retention, 1- vehiclem, 2- Non-Motor Vehicle, 3- Pedestrians
    //    BYTE byRes2[2];
    //    char sLicense[MAX_LICENSE_LEN/*16*/];    //License No
    //    BYTE byRegion;     //Region index value, 0 reserved, 1 Europe, 2 Russia(Russian regions), 3-EU&&CIS,4-Middle East,0xff- all
    //    BYTE byCountry;     // Country INdex ,Reference:COUNTRY_INDEX
    //    BYTE byArea;        //Area of Country
    //    BYTE byRes3[5];
    //}
    //NET_DVR_FIND_PICTURE_PARAM, * LPNET_DVR_FIND_PICTURE_PARAM;

    [StructLayout(LayoutKind.Sequential)]
    public struct NET_DVR_FIND_PICTURE_PARAM
    {
        public uint dwSize;
        public long lChannel;
        public byte byFileType;   /* ???????:0????1 ?????? 2 ????3  ?? | ?????? 4 ?? & ??????
                                       * 6 ???? ,9-????,10- PIR??,11- ????,12- ????,0xa ?????,0xd ????,
                                       * 0xe ????,0xf ??????,0x10 ??????, 0x11-?????????, 0x12-????,
                                       * 0xff- ???? 2013-07-16*/
        public byte byProvince;
        //public uint dwIsLocked;        
        public byte byNeedCard;
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 2, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes;      // ????
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 40, ArraySubType = UnmanagedType.I1)]
        public byte[] sCardNum;     // ??
        public NET_DVR_TIME struStartTime;
        public NET_DVR_TIME struStopTime;
        public uint dwTrafficType;
        public uint dwVehicleType;
        public uint dwIllegalType;
        public byte byLaneNo;
        public byte bySubHvtType;
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 9, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes2;
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 16, ArraySubType = UnmanagedType.I1)]
        public byte[] sLicense;
        public byte byRegion;
        public byte byCountry;
        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 6, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes3;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct NET_DVR_FIND_DATA
    {
        public string sFileName;
        public NET_DVR_TIME struStartTime;
        public NET_DVR_TIME struStopTime;
        public uint dwFileSize;
    }

    [StructLayout(LayoutKind.Sequential)]
    public struct NET_DVR_FINDDATA_V30
    {
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 100)]
        public string sFileName;//ÎÄ¼þÃû
        public NET_DVR_TIME struStartTime;//ÎÄ¼þµÄ¿ªÊ¼Ê±¼ä
        public NET_DVR_TIME struStopTime;//ÎÄ¼þµÄ½áÊøÊ±¼ä
        public uint dwFileSize;//ÎÄ¼þµÄ´óÐ¡
        [MarshalAsAttribute(UnmanagedType.ByValTStr, SizeConst = 32)]
        public string sCardNum;
        public byte byLocked;//9000Éè±¸Ö§³Ö,1±íÊ¾´ËÎÄ¼þÒÑ¾­±»Ëø¶¨,0±íÊ¾Õý³£µÄÎÄ¼þ
        public byte byFileType;

        [MarshalAsAttribute(UnmanagedType.ByValArray, SizeConst = 3, ArraySubType = UnmanagedType.I1)]
        public byte[] byRes;
    }




}
