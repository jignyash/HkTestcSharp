﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HIKSDKTest.Hikvision.Base
{
    public class Result
    {
        private bool _isSuccessful;
        private List<string> _errors;
        private int _intValue = -1;

        public Result()
        {
            _errors = new List<string>();
        }

        public Result(bool isSuccess)
        {
            _isSuccessful = isSuccess;
               _errors = new List<string>();
        }

        public bool IsSuccessful
        {
            get
            {
                return _isSuccessful;
            }

            set
            {
                _isSuccessful = value;
            }
        }

        public List<string> Errors
        {
            get
            {
                return _errors;
            }

            set
            {
                _errors = value;
            }
        }

        public int IntValue
        {
            get
            {
                return _intValue;
            }

            set
            {
                _intValue = value;
            }
        }

        public void AddError(string message)
        {
            _errors.Add(message);
        }
    }
}
