﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace HIKSDKTest.Hikvision.Base
{
    public static class SDKMethods
    {
        public delegate void fLoginResultCallBack(int lUserID, uint dwResult, NET_DVR_DEVICEINFO_V30 lpDeviceInfo, IntPtr pUser);
        
        #region RealPlay_V40
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_Init")]
        public static extern bool NET_DVR_Init();

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_SetConnectTime")]
        public static extern bool NET_DVR_SetConnectTime(UInt32 dwWaitTime, UInt32 dwTryTimes);

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_SetReconnect")]
        public static extern bool NET_DVR_SetReconnect(UInt32 dwInterval = 30000, bool bEnableRecon = true);
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_Login_V30")]
        public static extern int NET_DVR_Login_V30(string sDVRIP, ushort wDVRPort, string sUserName, string sPassword, ref NET_DVR_DEVICEINFO_V30 lpDeviceInfo);

        public delegate void fRealDataCallBack_V30(int lRealHandle, uint dwDataType, byte[] pBuffer, uint dwBufSize, IntPtr pUser);
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_RealPlay_V40")]
        public static extern int NET_DVR_RealPlay_V40(int lUserID, ref NET_DVR_PREVIEWINFO lpPreviewInfo, fRealDataCallBack_V30 fRealDataCallBack_V30, IntPtr pUser);
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_StopRealPlay")]
        public static extern bool NET_DVR_StopRealPlay(int lRealHandle);
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_Logout")]
        public static extern bool NET_DVR_Logout(int lUserID);

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_Cleanup")]
        public static extern bool NET_DVR_Cleanup();
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_GetLastError")]
        public static extern UInt32 NET_DVR_GetLastError();
        #endregion RealPlay_V40

        #region Download picture 

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_GetFileByTime_V40")]
        public static extern int NET_DVR_GetFileByTime_V40(int lUserID, string sSavedFileName,NET_DVR_PLAYCOND pDownloadCond);

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_GetPicture")]
        public static extern bool NET_DVR_GetPicture(int lUserID, string sDVRFileName, string pDosSavedFileNamewnloadCond);

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_FindPicture")]
        public static extern int NET_DVR_FindPicture( int lUserID, ref NET_DVR_FIND_PICTURE_PARAM pFindParam);

        //NET_DVR_FindFile

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_FindFile")]
        public static extern int NET_DVR_FindFile(int lUserID, int lChannel, uint dwFileType, ref NET_DVR_TIME lpStartTime, ref NET_DVR_TIME lpStopTime);


        //NET_DVR_FindNextFile
        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_FindNextFile")]

        public static extern int NET_DVR_FindNextFile(int lFindHandle, ref NET_DVR_FIND_DATA lpFindData);

        [DllImport(@"\Hikvision\CppDlls\HCNetSDK.dll", EntryPoint = "NET_DVR_FindNextFile_V30")]
        public static extern int NET_DVR_FindNextFile_V30(int lFindHandle, ref NET_DVR_FINDDATA_V30 lpFindData);

        #endregion
    }
}
